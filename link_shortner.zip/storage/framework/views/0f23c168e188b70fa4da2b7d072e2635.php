<div class="header">

</div>
<?php /**PATH C:\laragon\www\link_shortner\resources\views/inc/header.blade.php ENDPATH**/ ?>