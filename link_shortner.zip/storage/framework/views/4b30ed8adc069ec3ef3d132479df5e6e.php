<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            URL Shortener
        </div>
        <div class="card-body">
            <div class="form-group">
                <label for="originalUrl">Enter your URL:</label>
                <input type="url" class="form-control" id="originalUrl" placeholder="https://example.com" required>
            </div>
            <button class="btn btn-primary btn-block" id="shortenBtn">Shorten URL</button>
            <div id="shortenedUrl" data-route="">
                <p><strong>Shortened URL:</strong></p>
                <a href="#" target="_blank" id="shortUrlLink"></a>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script>
        $(document).ready(function () {
            $('#shortenBtn').click(function () {

                var originalUrl = $('#originalUrl').val();
                var userId = <?php echo json_encode(auth()->check() ? auth()->user()->id : null, 15, 512) ?>;
                var baseUrl = "<?php echo e(url('/')); ?>";

                $.ajax({
                    url: '/api/getShorteningLink',
                    method: 'GET',
                    data: {
                        originalUrl: originalUrl,
                        userId: userId
                    },
                    success: function (response) {
                        console.log(response);
                        var shortenedUrl = response.data;
                        var redirectUrl = baseUrl + '/' + shortenedUrl;
                        $('#shortUrlLink').attr('href', redirectUrl).text("<?php echo e(env('APP_URL')); ?>" + "/" + shortenedUrl);


                        document.getElementById("shortenedUrl").style.display = "block";
                    },
                    error: function (xhr, status, error) {
                        console.error(xhr.responseText);
                    }
                });
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\link_shortner\resources\views/pages/home.blade.php ENDPATH**/ ?>