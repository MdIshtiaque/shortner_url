<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <a class="navbar-brand" href="<?php echo e(route('home')); ?>">URL Shortener</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarText"
            aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarText">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item active">
                <a class="nav-link" href="<?php echo e(route('home')); ?>">Home <span class="sr-only">(current)</span></a>
            </li>
            <?php if(auth()->check() != ''): ?>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('user.dashboard')); ?>">Dashboard</a>
                </li>
            <?php endif; ?>
        </ul>
        <span class="navbar-text">
            <?php if(auth()->check() == ''): ?>
                <div class="d-flex align-items-center">
                    <a href="<?php echo e(route('login')); ?>" class="btn btn-primary ml-2">Login</a>
                    <form action="<?php echo e(route('register')); ?>" method="get">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-success ml-2">Signup</button>
                </form>
            </div>
            <?php else: ?>
                <div class="d-flex align-items-center">
                    <p class="pr-2 pl-5 mb-0"><span style="font-weight: bold">Hi, <?php echo e(auth()->user()->name); ?></span></p>
                    <form action="<?php echo e(route('logoutUser')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-success">Log out</button>
                    </form>
                </div>
            <?php endif; ?>
        </span>
    </div>
</nav>
<?php /**PATH C:\laragon\www\link_shortner\resources\views/inc/navbar.blade.php ENDPATH**/ ?>